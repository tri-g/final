import { Component, OnInit } from '@angular/core';
import {ProductInformation} from "./../product-information";
import { ActivatedRoute, Router } from '@angular/router';
import { UsersServiceService } from '../users-service.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {

 id:number;
	product:ProductInformation;

  constructor(private route:ActivatedRoute,private router: Router,
  	private userService: UsersServiceService) { }

  ngOnInit() {
    this.product=new ProductInformation();
    this.id=this.route.snapshot.params['id'];
    this.userService.getProductUpdate(this.id)
    .subscribe(data=>{
      console.log(data)
      this.product=data;
    },
    error=>console.log(error));
  }

  updateEmployee(){
    this.userService.updateProduct(this.id,this.product)
    .subscribe(data=>console.log(data),
      error=>console.log(error));
    this.product=new ProductInformation();
    this.gotoList();
  }
  onSubmit(){
    this.updateEmployee();
  }
  gotoList(){
    this.router.navigate(['/product']);
  }

}

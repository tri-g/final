package com.example.minilogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniloginApplicationTests {

	@Test
	void contextLoads() {
	}

}
